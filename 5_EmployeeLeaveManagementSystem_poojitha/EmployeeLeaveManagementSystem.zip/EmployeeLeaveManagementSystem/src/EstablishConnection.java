import java.sql.Connection;
import java.sql.DriverManager;

public class EstablishConnection {
	
 Connection establishConnection() {
    	Connection connection=null;
    	try {
    	Class.forName("com.mysql.jdbc.Driver");
    	connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","poojitha");  
    	return connection;
    }catch(Exception e) {
    	System.out.println(e);
    }
    
    return connection;
}
}