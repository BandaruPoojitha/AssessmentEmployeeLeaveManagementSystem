
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ArrayList;

public class LeaveValidation {
	static int dayscount=0;
	ArrayList<Object> arraylist=null;
	ValidLOP validlop=new ValidLOP();
	boolean strechLeaves(String startdate,int noofdays) {
		System.out.println("1poo");
		while(noofdays+dayscount<5 ) {
			arraylist=validlop.validLeaves(startdate);
			if(arraylist.isEmpty()) {
				return true;
			}
			else {
			 dayscount=(int)arraylist.get(1);
			startdate= arraylist.get(0).toString();
			System.out.println(dayscount+"poo"+startdate);
			}
	}
		return false;
	}
	void leaveValid(String leaveType,String startdate,String enddate,String applyTo,String reason) {
		System.out.println("2poo");
	
		
		Date fromdate=null;
		Date Todate=null;
		ValidLogin v=new ValidLogin();
		AddLeave al=new AddLeave();
		Days d=new Days();
		int noofdays=d.countDays(startdate, enddate);
		if(strechLeaves(startdate,noofdays)) {
			

				if(leaveType.equals("Paid")) {
					if(v.paidLeavesValid()>=noofdays) {
						al.addLeave(leaveType, startdate, enddate, applyTo, reason,noofdays);
					}
					else if(v.paidLeavesValid()<noofdays) {
						leaveType="LOP";
						if(noofdays<=3)
							al.addLeave(leaveType, startdate, enddate, applyTo, reason,noofdays);
					}
				}
				else if(leaveType.equals("LOP")) {
					if(noofdays<=3) {  
						try {
							fromdate=new SimpleDateFormat("yyyy-MM-dd").parse(startdate);  
							Todate= new SimpleDateFormat("yyyy-MM-dd").parse(enddate);  
						}catch(Exception e) {
							System.out.println(e);
						}
						System.out.println(fromdate+"  hi"+Todate);
						System.out.println(fromdate.getMonth()+"Month"+Todate.getMonth());
						int totalLop=validlop.validLOP(fromdate,Todate);
						if((totalLop+noofdays)<=3)
							al.addLeave(leaveType, startdate, enddate, applyTo, reason,noofdays);
					}
				}
			
		}
		else {
			System.out.println("leave cannot be applied");
		}
	}
}
