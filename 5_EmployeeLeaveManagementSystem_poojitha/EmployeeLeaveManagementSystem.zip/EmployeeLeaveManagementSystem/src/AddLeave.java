
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AddLeave {
	int getLeavePaid() {
		try {
			  Connection connection=new EstablishConnection().establishConnection();
			  String query="select * from balanceleaves where employeeId=?";
			  PreparedStatement preparedstatement=connection.prepareStatement(query);
			  preparedstatement.setString(1, Bean.getEmployeeId());
		   	   ResultSet resultset=preparedstatement.executeQuery();
		   	   while(resultset.next())
		   		   return resultset.getInt(2);
		 }catch(Exception e) {
			 System.out.println(e);
		 }
	 
	 return -1;
	}
	int getLeaveLOP() {
		try {
			  Connection connection=new EstablishConnection().establishConnection();
			  String query="select * from balanceleaves where employeeId=?";
			  PreparedStatement preparedstatement=connection.prepareStatement(query);
			  preparedstatement.setString(1, Bean.getEmployeeId());
		   	   ResultSet resultset=preparedstatement.executeQuery();
		   	   while(resultset.next())
		   		   return resultset.getInt(3);
		 }catch(Exception e) {
			 System.out.println(e);
		 }
	 
	 return -1;
	}
	 int deductLeave(String leavetype,int days,String employeeId) {
		 if(leavetype.equals("Paid")) {
			 int number=getLeavePaid()-days;
			 System.out.println(number+"paid");
			 try {
				  Connection con=new EstablishConnection().establishConnection();
				  String  query="update balanceleaves set Paid=? where employeeId=? ";
				  PreparedStatement preparedstatement=con.prepareStatement( query);
				  preparedstatement.setInt(1, number);
				  preparedstatement.setString(2,employeeId);
			   	int resultset=preparedstatement.executeUpdate();
				  if(resultset>0)
					  System.out.println("updated in leavebalance");
			 }catch(Exception e) {
				 System.out.println(e);
			 }
		 }
		 else if(leavetype.equals("LOP")) {
			 int number=getLeaveLOP()+days;
			 System.out.println(number+"lpo");
			 try {
				  Connection connection=new EstablishConnection().establishConnection();
				  String query="update balanceleaves set LOP=? where employeeId=? ";
				  PreparedStatement preparedstatement=connection.prepareStatement(query);
				  preparedstatement.setInt(1, number);
				  preparedstatement.setString(2, employeeId);
			int resultset=preparedstatement.executeUpdate();
			  if(resultset>0)
				  System.out.println("updated in leavebalance");
			 }catch(Exception e) {
				 System.out.println(e);
			 }
		 }
		 return -1;
	 }
	 int addLeaveCount(String leavetype,int days) {
		 if(leavetype.equals("Paid")) {
			 int number=getLeavePaid()+days;
			 System.out.println(number+"paid");
			 try {
				  Connection connection=new EstablishConnection().establishConnection();
				  String query="update balanceleaves set Paid=? where employeeId=? ";
				  PreparedStatement preparedstatement=connection.prepareStatement(query);
				  preparedstatement.setInt(1, number);
				  preparedstatement.setString(2, Bean.getEmployeeId());
			   	int resultset=preparedstatement.executeUpdate();
				  if(resultset>0)
					  System.out.println("updated in leavebalance");
			 }catch(Exception e) {
				 System.out.println(e);
			 }
		 }
		 else if(leavetype.equals("LOP")) {
			 int number=getLeaveLOP()-days;
			 System.out.println(number+"lpo");
			 try {
				  Connection connection=new EstablishConnection().establishConnection();
				  String query="update balanceleaves set LOP=? where employeeId=? ";
				  PreparedStatement preparedstatement=connection.prepareStatement(query);
				  preparedstatement.setInt(1, number);
				  preparedstatement.setString(2, Bean.getEmployeeId());
			int resultset=preparedstatement.executeUpdate();
			  if(resultset>0)
				  System.out.println("updated in leavebalance");
			 }catch(Exception e) {
				 System.out.println(e);
			 }
		 }
		 return -1;
	 }
	
  void addLeave(String leaveType,String startdate,String enddate,String applyTo,String reason,int days) {
	  try {
   	   Connection connection=new EstablishConnection().establishConnection();
   	   String query="insert into ApplyLeave(employeeId,LeaveType,startdate,enddate,applyTo,reason,status,NoofDays) values(?,?,?,?,?,?,?,?)";
   	   PreparedStatement preparedstatement=connection.prepareStatement(query);
   	preparedstatement.setString(1, Bean.getEmployeeId());
   	preparedstatement.setString(2, leaveType);
   	preparedstatement.setString(3, startdate);
   	preparedstatement.setString(4, enddate);
   	preparedstatement.setString(5, applyTo);
   	preparedstatement.setString(6,reason);
   	preparedstatement.setString(7, "processing");
   	preparedstatement.setInt(8, days);
   	   int resultset=preparedstatement.executeUpdate();
   	   if(resultset>0)
   		   System.out.println("updated in leavetable");
	   }catch(Exception e) {
		   System.out.println(e);
	   }
	 //deductLeave(leaveType,days);
  }
}
