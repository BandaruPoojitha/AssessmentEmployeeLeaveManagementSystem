import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class CreateEmployee {
	String getManagerId(String departmentId) {
		try {
	        Connection connection=new EstablishConnection().establishConnection();
	 	
  	      String query="select * from Department where (departmentId=?) " ;
	      PreparedStatement preparedstatement=connection.prepareStatement(query);
	      preparedstatement.setString(1,departmentId);
	    
	      ResultSet resultset=preparedstatement.executeQuery();
	       while(resultset.next())
	    	   return resultset.getString(2);
	   }catch(Exception e) {
		   System.out.println(e);
	   }
	   return "null";
	}
       void addEmployee(String employeeName,String employeeId,String departmentId,String managerId,String address,String email,String phonenumber) {
    	   //String managerId=getManagerId(departmentId);
    	   addLogin(employeeId,employeeName);
    	   addLeave(employeeId);
    	   System.out.println("manager id"+managerId);
    	   try {
    	   Connection connection=new EstablishConnection().establishConnection();
    	   String query="insert into CreateEmployee(employeeName,employeeId,departmentId,managerId,address,email,phonenumber) values(?,?,?,?,?,?,?)";
    	   PreparedStatement preparedstatement=connection.prepareStatement(query);
    	   preparedstatement.setString(1, employeeName);
    	   preparedstatement.setString(2, employeeId);
    	   preparedstatement.setString(3, departmentId);
    	   preparedstatement.setString(4, managerId);
    	   preparedstatement.setString(5, address);
    	   preparedstatement.setString(6, email);
    	   preparedstatement.setString(7, phonenumber);
    	  int resultset=preparedstatement.executeUpdate();
    	  if(resultset>0)
    		  System.out.println("added");
       }catch(Exception e) {
    	   System.out.println(e);
       }
       }
       void addLogin(String employeeId,String employeeName) {
    	   try {
        	   Connection connection=new EstablishConnection().establishConnection();
        	   String query="insert into Login1(EmployeeId,password,EmployeeType) values(?,?,?)";
        	   PreparedStatement preparedstatement=connection.prepareStatement(query);
        	   preparedstatement.setString(1, employeeId);
        	   preparedstatement.setString(2,employeeName+ employeeId);
        	   preparedstatement.setString(3, "Employee");
        	   int resultset=preparedstatement.executeUpdate();
        	   if(resultset>0)
        		   System.out.println("updated in login");
    	   }catch(Exception e) {
    		   System.out.println(e);
    	   }
       }
       void addLeave(String employeeId) {
    	   try {
        	   Connection connection=new EstablishConnection().establishConnection();
        	   String query="insert into BalanceLeaves(EmployeeId,Paid,LOP) values(?,?,?)";
        	   PreparedStatement preparedstatement=connection.prepareStatement(query);
        	   preparedstatement.setString(1, employeeId);
        	   preparedstatement.setInt(2,10);
        	   preparedstatement.setInt(3, 0);
        	   int resultset=preparedstatement.executeUpdate();
        	   if(resultset>0)
        		   System.out.println("updated in Leave");
    	   }catch(Exception e) {
    		   System.out.println(e);
    	   }
       }
}
