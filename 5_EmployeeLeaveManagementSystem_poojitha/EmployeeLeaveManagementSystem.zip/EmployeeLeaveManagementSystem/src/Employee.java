
import leave.LeaveDetails;
import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Employee
 */
@WebServlet("/Employee")
public class Employee extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Employee() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession(true);
		if(request.getParameter("value").equals("1")) {
			System.out.println("apply leave:");
			RequestDispatcher rd=request.getRequestDispatcher("ApplyLeave.jsp");
			rd.forward(request, response);
		}
		else if(request.getParameter("value").equals("2")) {
			System.out.println("grant leave");
			GrantLeave gl=new GrantLeave();
			session.setAttribute("ids",gl.grantLeave());
			RequestDispatcher rd=request.getRequestDispatcher("GrantLeave.jsp");
			rd.forward(request, response);
		}
		else if(request.getParameter("value").contentEquals("3")) {
			System.out.println("cancel leave");
			CancelLeave cl=new CancelLeave();
			session.setAttribute("cancel",cl.cancelLeave());
			System.out.print(session.getAttribute("cancel"));
			RequestDispatcher rd=request.getRequestDispatcher("CancelLeave.jsp");
			rd.forward(request, response);
		}
		else if(request.getParameter("value").equals("4")) {
			System.out.println("track my leave");
			CancelLeave cl=new CancelLeave();
			session.setAttribute("track",cl.cancelLeave());
			RequestDispatcher rd=request.getRequestDispatcher("TrackMyLeave.jsp");
			rd.forward(request, response);
		}
		else if(request.getParameter("value").equals("5")) {
			System.out.println("LeaveBalance");
			LeaveBalance lb=new LeaveBalance();
			session.setAttribute("leavebal",lb.leaveBalance());
			System.out.println(lb.leaveBalance()+"bal");
			int[] a=lb.leaveBalance();
			
			RequestDispatcher rd=request.getRequestDispatcher("LeaveBalance.jsp");
			rd.forward(request, response);
		}
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession(true);
		System.out.println(session.getAttribute("value")+"out");
		if(session.getAttribute("value").equals("0")) {
			CreateEmployee ce=new CreateEmployee();
			Validation v=new Validation();
			String employeeName= request.getParameter("name");
			String employeeId=request.getParameter("EmployeeId");
			String departmentId=request.getParameter("departmentId");
			String managerId=request.getParameter("managerId");
			String address=request.getParameter("address");
			String email=request.getParameter("Email");
			if(v.emailValidation(email)){
		    String contactnumber=request.getParameter("phonenumber");
		    if(v.validatephonenumber(contactnumber)) {
		    System.out.println(employeeName+employeeId+departmentId+managerId+contactnumber);
		    ce.addEmployee(employeeName,employeeId,departmentId,managerId,address,email,contactnumber);
		    response.sendRedirect("Employee.jsp");
			}
			}
		}
		else if(session.getAttribute("value").equals("1")) {
	
			System.out.println(session.getAttribute("value")+"inside");
			String leaveType=request.getParameter("LeaveType");
			String startdate=request.getParameter("startdate");
			String enddate=request.getParameter("enddate");
			ValidLogin vl=new ValidLogin();
			String applyTo=vl.managerId();
		    String reason=request.getParameter("reason");
		   LeaveValidation lv=new LeaveValidation();
		   lv.leaveValid(leaveType,startdate,enddate,applyTo,reason);
		  response.sendRedirect("Employee.jsp");
		}
	}

}
