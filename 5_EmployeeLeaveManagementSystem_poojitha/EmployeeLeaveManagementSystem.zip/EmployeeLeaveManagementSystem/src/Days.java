import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.sql.*;
import java.util.Date;

public class Days {
	private static final DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
 int countDays(String dateStart,String dateStop) {
	 try {
	 Date one = getDate(dateStart);
     Date two = getDate(dateStop);
	
System.out.println(daysBetween(one,two));
    return (int)daysBetween(one,two);
	} catch (Exception e) {
		e.printStackTrace();
	}
	 return -1;
}
private static Date getDate(String date) throws ParseException{
  return  df.parse(date);
}
 static long daysBetween(Date one, Date two) {
  long difference =  (one.getTime()-two.getTime())/86400000;
  return Math.abs(difference);
}
   
}

