import leave.LeaveDetails;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class CancelLeave {
      ArrayList<LeaveDetails> al=new ArrayList<LeaveDetails>();
      ArrayList<LeaveDetails> cancelLeave() {
    	  try {
			  Connection connection=new EstablishConnection().establishConnection();
			  String query="select * from applyleave where employeeId=?";
			  PreparedStatement preparedstatement=connection.prepareStatement(query);
			  System.out.println(Bean.getEmployeeId()+"id");
			  preparedstatement.setString(1, Bean.getEmployeeId());
		   	   ResultSet resultset=preparedstatement.executeQuery();
		         //System.out.println("Hello1");
		         System.out.println(resultset.getFetchSize()+"size");
		   	   while(resultset.next())
		   	   {   //System.out.println("helo3");
		   		   LeaveDetails ld=new LeaveDetails();
		   		   System.out.println(resultset.getString(1)+resultset.getString(2)+resultset.getDate(3)+resultset.getDate(4)+resultset.getString(5)+resultset.getString(6)+resultset.getString(7));
		   		   ld.setEmployeeId(resultset.getString(1));
		   		   ld.setLeaveType(resultset.getString(2));
		   		   ld.setStartdate(resultset.getDate(3));
		   		  ld.setEnddate(resultset.getDate(4));
		   		  ld.setApplyTo(resultset.getString(5));
		   		  ld.setReason(resultset.getString(6));
		   		  ld.setStatus(resultset.getString(7));
		   	   al.add(ld);
		   	  
		   	   }
		   	 System.out.println(al.size()+"alsize");
		   	   return al;
		 }catch(Exception e) {
			 System.out.println(e);
		 }
    	  return null;
      }
}
