import leave.LeaveDetails;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class GrantLeave {
      ArrayList<LeaveDetails> arraylist=new ArrayList<LeaveDetails>();
      ArrayList<LeaveDetails> grantLeave() {
    	  try {
   			  Connection connection=new EstablishConnection().establishConnection();
			  String query="select * from applyleave where applyTo=? and (status=?)";
			  PreparedStatement preparedstatement=connection.prepareStatement(query);
			  System.out.println(Bean.getEmployeeId()+"id");
			  preparedstatement.setString(1, Bean.getEmployeeId());
			  preparedstatement.setString(2, "processing");
		   	   ResultSet resultset=preparedstatement.executeQuery();
		         //System.out.println("Hello1");
		         System.out.println(resultset.getFetchSize()+"size");
		   	   while(resultset.next())
		   	   {   //System.out.println("helo3");
		   		 LeaveDetails leavedetails=new LeaveDetails();
		   		   System.out.println(resultset.getString(1)+resultset.getString(2)+resultset.getDate(3)+resultset.getDate(4)+resultset.getString(5)+resultset.getString(6)+resultset.getString(7));
		   		leavedetails.setEmployeeId(resultset.getString(1));
		   		leavedetails.setLeaveType(resultset.getString(2));
		   		leavedetails.setStartdate(resultset.getDate(3));
		   		leavedetails.setEnddate(resultset.getDate(4));
		   		leavedetails.setApplyTo(resultset.getString(5));
		   		leavedetails.setReason(resultset.getString(6));
		   		leavedetails.setStatus(resultset.getString(7));
		   		arraylist.add(leavedetails);
		   	  
		   	   }
		   	 System.out.println(arraylist.size()+"alsize");
		   	   return arraylist;
		 }catch(Exception e) {
			 System.out.println(e);
		 }
    	  return null;
      }
}
