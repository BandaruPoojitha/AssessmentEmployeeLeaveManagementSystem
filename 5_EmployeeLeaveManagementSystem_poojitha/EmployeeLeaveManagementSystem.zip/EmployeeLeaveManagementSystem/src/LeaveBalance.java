import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class LeaveBalance {
      int[] a=new int[2];
      int[] leaveBalance(){
    	   try {
				  Connection connection=new EstablishConnection().establishConnection();
				  String query="select * from BalanceLeaves where employeeId=?";
				  PreparedStatement preparedstatement=connection.prepareStatement(query);
				  preparedstatement.setString(1, Bean.getEmployeeId());
				  ResultSet resultset=preparedstatement.executeQuery();
				  while(resultset.next()) {
					  a[0]=resultset.getInt(2);
					  a[1]=resultset.getInt(3);
				  }
				  return a;
       }catch(Exception e) {
    	   System.out.println(e);
       }
    	   return null;
}
}
