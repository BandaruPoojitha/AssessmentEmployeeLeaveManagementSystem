import java.sql.Connection;
import java.util.ArrayList;
import java.util.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ValidLOP {
	int countdays=0;
	   ArrayList<Object> validLeaves(String startdate){
			 System.out.println("valip1poo");
   ArrayList<Object> arraylist=new ArrayList<>();
	  try {
	   	   Connection con=new EstablishConnection().establishConnection();
	   	  String query="select * from applyLeave where (enddate=?) and (employeeId=?) ";
		  PreparedStatement preparedstatement=con.prepareStatement(query);
		  preparedstatement.setString(1, startdate);
		  preparedstatement.setString(2, Bean.getEmployeeId());
	   	   ResultSet resultset=preparedstatement.executeQuery();
	   	   while(resultset.next()) {
	   		  countdays+=resultset.getInt(8);
	   		  System.out.println("Countdays"+countdays);
	   		  arraylist.add(resultset.getDate(3));
	   		 arraylist.add(countdays);
	   		 System.out.println(resultset.getInt(8)+"hi"+resultset.getDate(3));
	   	   }
	   	   System.out.println(arraylist);
	   	   return arraylist;
	   	}catch(Exception e) {
 		   System.out.println(e);
 	   }
	  return null;
	}
		
       int validLOP(Date startdate,Date enddate) {
    	   int count=0;
    	  int startmonth=startdate.getMonth()+1;
    	  int endmonth=enddate.getMonth()+1;
    	   try {
    	   	   Connection con=new EstablishConnection().establishConnection();
    	   	  String query="select * from applyLeave where (MONTH(enddate)=?) and (MONTH(startdate)=?) and (LeaveType=?) and (employeeId=?) ";
			  PreparedStatement preparedstatement=con.prepareStatement(query);
			  preparedstatement.setInt(1,startmonth);
			  preparedstatement.setInt(2,endmonth);
			  preparedstatement.setString(3, "LOP");
			  preparedstatement.setString(4, Bean.getEmployeeId());
		   	   ResultSet resultset=preparedstatement.executeQuery();
		   	   while(resultset.next()) {
		   		  count+=resultset.getInt(8);
		   	   }
		   	   System.out.println(startmonth+" "+endmonth);
		   	   System.out.println("Total no of LOP"+count);
		   	   return count;
    	   }catch(Exception e) {
    		   System.out.println(e);
    	   }
    	   return -1;
       }
}
