import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Date;
public class Status {
	String getStatus(Date start,Date end,String type) {
		try {
			Connection connection=new EstablishConnection().establishConnection();
			String str1="select * from applyleave where (employeeId=?) and (startdate=?) and (enddate=?) and (LeaveType=?)";
			PreparedStatement preparedstatement=connection.prepareStatement(str1);
			preparedstatement.setString(1, Bean.getEmployeeId());
			preparedstatement.setDate(2, start);
			preparedstatement.setDate(3, end);
			preparedstatement.setString(4, type);
			ResultSet resultset=preparedstatement.executeQuery();
			while(resultset.next()) {
				return resultset.getString(7);
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		return "null";
	}
	void leavededuct(String employeeId,String Type,Date start,Date end) {
		AddLeave al=new AddLeave();
		
	    	Days d=new Days();
	    	int days=(int)d.daysBetween(start, end);
	    	System.out.println("days"+days);
		al.deductLeave(Type,days,employeeId);
	
	}
    void statusUpdate(String status,String employeeId,Date startdate,Date enddate,String leaveType) {
    	System.out.println("status"+status);
    	try {
    	Connection con=new EstablishConnection().establishConnection();
    	String str="update applyleave set status=? where (employeeId=?) and (applyTo=?) and (startdate=?) and (enddate=?) and (LeaveType=?)";
    	PreparedStatement preparedstatement=con.prepareStatement(str);
    	preparedstatement.setString(1,status );
    	preparedstatement.setString(2,employeeId);
    	System.out.println("a");
    	preparedstatement.setString(3, Bean.getEmployeeId());
    	preparedstatement.setDate(4, startdate);
    	preparedstatement.setDate(5, enddate);
    	System.out.println("b");
    	preparedstatement.setString(6, leaveType);
    	int resultset=preparedstatement.executeUpdate();
    	if(resultset>0) {
    		System.out.println("updated succesfully!!");
    	}
    	if(status.equals("accept")) {
    		System.out.println(employeeId);
    		leavededuct(employeeId,leaveType,startdate,enddate);
    	}
    	}catch(Exception e) {
    		System.out.println(e);
    	}
    }
    void deleteLeave(Date start,Date end,String leaveType,String value) {
    	if(value.equals("cancel")) {
    	Days d=new Days();
    	AddLeave al=new AddLeave();
    	int days=(int)d.daysBetween(start,end);
    	System.out.println("days"+days);
    	try {
    	String status=getStatus(start,end,leaveType);
    		System.out.println("Status"+status);
    		if(status.equals("accept")) {
    			al.addLeaveCount(leaveType, days);
    		}
        	Connection con=new EstablishConnection().establishConnection();
        	String str="delete from applyleave where (employeeId=?) and (startdate=?) and (enddate=?) and (LeaveType=?)";
        	PreparedStatement preparedstatement=con.prepareStatement(str);
        	preparedstatement.setString(1, Bean.getEmployeeId());
        	preparedstatement.setDate(2,start);
        	preparedstatement.setDate(3, end);
        	preparedstatement.setString(4, leaveType);
        	int resultset=preparedstatement.executeUpdate();
        	if(resultset>0)
        		System.out.println("deleted succesfully!!");
        	
        	}catch(Exception e) {
        		System.out.println(e);
        	}
    	}
    }
}
