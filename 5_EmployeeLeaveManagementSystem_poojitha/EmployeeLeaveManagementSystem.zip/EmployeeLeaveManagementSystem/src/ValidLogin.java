import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;

public class ValidLogin {
      String valid(String employeeId,String password) {
    	  try {
		        Connection con=new EstablishConnection().establishConnection();
		 	
	  	      String query="select * from Login1 where (employeeId=?) and (password=?)" ;
		      PreparedStatement preparedstatement=con.prepareStatement(query);
		      preparedstatement.setString(1,employeeId);
		      preparedstatement.setString(2,password);
		      ResultSet resultset=preparedstatement.executeQuery();
		       while(resultset.next())
		    	   return resultset.getString(3);
		   }catch(Exception e) {
			   System.out.println(e);
		   }
		   return "null";
	}
      int paidLeavesValid() {
    	  try {
		        Connection con=new EstablishConnection().establishConnection();
		 	
	  	      String query="select * from BalanceLeaves where (EmployeeId=?) " ;
		      PreparedStatement preparedstatement=con.prepareStatement(query);
		      preparedstatement.setString(1,Bean.getEmployeeId());
		      ResultSet resultset=preparedstatement.executeQuery();
		       while(resultset.next())
		    	   return resultset.getInt(2);
		   }catch(Exception e) {
			   System.out.println(e);
		   }
    	  return 0;
      }
      String managerId() {
    	  try {
		        Connection con=new EstablishConnection().establishConnection();
		 	
	  	      String query="select * from createEmployee where (EmployeeId=?) " ;
		      PreparedStatement preparedstatement=con.prepareStatement(query);
		      preparedstatement.setString(1,Bean.getEmployeeId());
		      ResultSet resultset=preparedstatement.executeQuery();
		       while(resultset.next())
		    	   return resultset.getString(4);
		   }catch(Exception e) {
			   System.out.println(e);
		   }
  	  return "null";
      }

      }
