package leave;
import java.sql.Date;

public class LeaveDetails {
        private String employeeId;
        private String  leaveType;
        private Date startdate;
        private Date enddate;
        private String applyTo;
         private String reason;
       private  String status;
         public String getEmployeeId() {
			return employeeId;
		}
		public void setEmployeeId(String employeeId) {
			this.employeeId = employeeId;
		}
		public String getLeaveType() {
			return leaveType;
		}
		public void setLeaveType(String leaveType) {
			this.leaveType = leaveType;
		}
		public Date getStartdate() {
			return startdate;
		}
		public void setStartdate(Date startdate) {
			this.startdate = startdate;
		}
		public Date getEnddate() {
			return enddate;
		}
		public void setEnddate(Date enddate) {
			this.enddate = enddate;
		}
		public String getApplyTo() {
			return applyTo;
		}
		public void setApplyTo(String applyTo) {
			this.applyTo = applyTo;
		}
		public String getReason() {
			return reason;
		}
		public void setReason(String reason) {
			this.reason = reason;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		
         
}
