

import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;

import leave.LeaveDetails;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class UpdateStatus
 */
@WebServlet("/UpdateStatus")
public class UpdateStatus extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateStatus() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int i;
		HttpSession session = request.getSession(true);
		
		int k=(int)session.getAttribute("sizeal");
		
		System.out.println(k+"sizejkl");
		Status s=new Status();
		for(i=0;i<k;i++) {
			String i1=new Integer(i).toString();
			 String value = request.getParameter("jk"+i1);
			 System.out.println(value+"value");
			 if(value.equals("cancel")) {
				 ArrayList<LeaveDetails> al1 = (ArrayList<LeaveDetails>) session.getAttribute("cancel");
				 LeaveDetails ld = al1.get(i);
				Date start= ld.getStartdate();
				Date end=ld.getEnddate();
				String leaveType=ld.getLeaveType();
			 System.out.println(end+leaveType+value+"kl"+start);
			s.deleteLeave(start,end,leaveType,value);
			  response.sendRedirect("Employee.jsp");
			 }
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int i,j;
		HttpSession session = request.getSession(true);
		int k=(int)session.getAttribute("sizeal");
		
		System.out.println("post method size"+k);

		Status s=new Status();
		for(i=0;i<k;i++) {
			String i1=new Integer(i).toString();
			 String value = request.getParameter("JK"+i1);
			 System.out.println(value+"value");
			 if(value.equals("accept")||value.equals("reject")) {
				 ArrayList<LeaveDetails> al1 = (ArrayList<LeaveDetails>) session.getAttribute("ids");
				 LeaveDetails ld = al1.get(i); 
				 String employeeId=ld.getEmployeeId();
				 Date start= ld.getStartdate();
					Date end=ld.getEnddate();
					String leaveType=ld.getLeaveType();
					System.out.println(value+employeeId+start+ "  poo  "+end+ leaveType);
					s.statusUpdate(value, employeeId, start, end, leaveType);
					 response.sendRedirect("Employee.jsp");
			 }
			
		 
		}
		
	}

}
