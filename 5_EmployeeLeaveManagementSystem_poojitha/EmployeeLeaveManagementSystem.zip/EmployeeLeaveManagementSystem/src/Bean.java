import java.sql.Date;

public class Bean {
	
  private static  String employeeId;
  private static String managerId;
  private static Date startdate;
  private static Date enddate;
    Date getStartdate() {
	return startdate;
}
void setStartdate(Date startdate) {
	this.startdate = startdate;
}
Date getenddate() {
	return enddate;
}
void setenddate(Date enddate) {
	this.enddate = enddate;
}
	void setEmployeeId(String employeeId) {
    	   this.employeeId=employeeId;
       }
      static String getEmployeeId() {
    	   return employeeId;
       }
      void setmanagerId(String managerId) {
   	   this.managerId=managerId;
      }
     static String getManagerId() {
   	   return managerId;
      }
      
}
